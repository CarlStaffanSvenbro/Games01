 
class W0300: W0200
{
    static var Objects = [W0200.ObjectStruct]()
     static func StaticReset0300()
      {
          StaticReset0200()
          Objects.removeAll()
      }
    
}
