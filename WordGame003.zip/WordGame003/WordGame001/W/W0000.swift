 
 class W0000: Dep99 {
    
    
    static var SectionCollapseEnabled = true
    static var SmallSizeTable: Bool = false
    static var GeneratedCode: String = ""
    
    static func StaticReset0000()
    {
        SectionCollapseEnabled = true
        SmallSizeTable = false
    }
     
}
