//
//  Warnings01.swift
//  WordGame001
//
//  Created by Carl-Staffan Svenbro on 2020-03-24.
//  Copyright © 2020 Carl-Staffan Svenbro. All rights reserved.
//

import UIKit

class Warnings01: Dep99 {
  
    static let Warning_AllowKeypadInputCommandBox = false
   

}
