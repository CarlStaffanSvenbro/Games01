//
//  MyIndependentClass.swift
//  WordGame001
//
//  Created by Carl-Staffan Svenbro on 2020-03-19.
//  Copyright © 2020 Carl-Staffan Svenbro. All rights reserved.
//

import Foundation

class Dep99: Dep01
{
    
    
    
    
    
    
    
}
